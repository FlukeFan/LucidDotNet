﻿using System;

namespace Module
{
    public class Class1
    {
    }
}
